from os.path import dirname
print(dirname(__file__))
# print(load_data.seewo_data().shape)


