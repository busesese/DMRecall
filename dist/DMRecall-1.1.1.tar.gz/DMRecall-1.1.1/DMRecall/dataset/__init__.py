from .load_data import mini_data


__all__ = ['mini_data']